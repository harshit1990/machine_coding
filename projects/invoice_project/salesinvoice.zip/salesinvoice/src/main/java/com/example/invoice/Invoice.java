package com.example.invoice;

public interface Invoice {
	
	public void start();

}
